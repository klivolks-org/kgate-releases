# OpenLiteSpeed reverse proxy for kGate

1. WebAdmin Console → **Virtual Hosts** → your host → **External App** →
   add a new **Web Server** external app pointing to `127.0.0.1:8080`.
2. Under **Context**, add a new Proxy context:
   - URI: `/`
   - Address: the external app created above
3. Enable WebSocket support: **Virtual Hosts → your host → General →
   Enable WebSocket** (needed for the Messenger component).
4. Restart OpenLiteSpeed (`systemctl restart lsws` or via WebAdmin).